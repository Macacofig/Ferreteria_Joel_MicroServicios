﻿using FERRETERIA__Joel.Dominio.Constantes;
using FERRETERIA__Joel.Dominio.Entidades;
using FERRETERIA__Joel.Dominio.Puertos;
using FERRETERIA__Joel.Infraestructura.Factories;

namespace FERRETERIA__Joel.Aplicacion.Servicios
{
    /// <summary>
    /// Bitácora de sesiones y de operaciones CRUD. Registra el empleado
    /// autenticado (identificador, nombre y rol), la operación, la entidad, el
    /// registro afectado, la fecha/hora y el resultado. Nunca recibe ni guarda
    /// contraseñas, hashes, JWT o tokens de activación.
    /// </summary>
    public class ServicioBitacora
    {
        public const string AccionLogin = "login";
        public const string AccionLogout = "logout";
        public const string AccionLoginFallido = "login_fallido";
        public const string OperacionInsert = "INSERT";
        public const string OperacionUpdate = "UPDATE";
        public const string OperacionDelete = "DELETE";

        private readonly RepositoryCreator<IRepositoryBitacora> _creadorRepositorio;
        private IRepositoryBitacora? _repositorio;

        public ServicioBitacora(
            RepositoryCreator<IRepositoryBitacora> creadorRepositorio)
        {
            _creadorRepositorio = creadorRepositorio;
        }

        private IRepositoryBitacora Repositorio =>
            _repositorio ??= _creadorRepositorio.CreateRepository();

        public async Task RegistrarLoginAsync(
            int? idUsuario,
            string? nombreUsuario,
            string tipoUsuario)
        {
            await RegistrarAsync(
                AccionLogin,
                idUsuario,
                nombreUsuario,
                tipoUsuario);
        }

        public async Task RegistrarLogoutAsync(
            int? idUsuario,
            string? nombreUsuario,
            string tipoUsuario)
        {
            await RegistrarAsync(
                AccionLogout,
                idUsuario,
                nombreUsuario,
                tipoUsuario);
        }

        public async Task RegistrarLoginFallidoAsync(
            string? nombreIdentificador,
            string tipoUsuario = "EmpleadoVenta")
        {
            await Repositorio.RegistrarOperacionAsync(
                AccionLoginFallido,
                null,
                null,
                "FALLIDO",
                null,
                nombreIdentificador,
                NormalizarRol(tipoUsuario));
        }

        /// <summary>
        /// Registra una operación CRUD real. <paramref name="exitoso"/> se
        /// traduce a EXITOSO/FALLIDO. El identificador del responsable debe
        /// provenir siempre del JWT validado, nunca de un valor enviado por el
        /// cliente.
        /// </summary>
        public async Task RegistrarOperacionAsync(
            string operacion,
            string entidad,
            int? idRegistroAfectado,
            bool exitoso,
            int? idUsuario,
            string? nombreUsuario,
            string tipoUsuario)
        {
            await Repositorio.RegistrarOperacionAsync(
                operacion,
                entidad,
                idRegistroAfectado,
                exitoso ? "EXITOSO" : "FALLIDO",
                idUsuario,
                nombreUsuario,
                NormalizarRol(tipoUsuario));
        }

        public async Task<List<RegistroBitacora>> ListarAsync(int limite)
        {
            int limiteSeguro = Math.Clamp(limite, 1, 500);

            return await Repositorio.ListarAsync(limiteSeguro);
        }

        private async Task RegistrarAsync(
            string accion,
            int? idUsuario,
            string? nombreUsuario,
            string tipoUsuario)
        {
            await Repositorio.RegistrarAsync(
                accion,
                idUsuario,
                nombreUsuario,
                NormalizarRol(tipoUsuario));
        }

        private static string NormalizarRol(string? tipoUsuario)
        {
            return string.IsNullOrWhiteSpace(tipoUsuario)
                ? RolesSistema.EmpleadoVenta
                : tipoUsuario;
        }
    }
}
